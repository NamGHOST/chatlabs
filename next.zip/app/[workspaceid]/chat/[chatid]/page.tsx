"use client"

import { ChatUI } from "@/components/chat/chat-ui"

export default function ChatIDPage() {
  return <ChatUI />
}
