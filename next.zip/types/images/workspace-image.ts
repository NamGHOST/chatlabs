export interface WorkspaceImage {
  workspaceId: string
  path: string
  base64: any // base64 image
  url: string
}
