alter table profiles
    add column system_prompt_template text;
